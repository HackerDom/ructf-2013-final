This is a very custom build based on brson's "struct-return" branch.

None of compliers in the public access will work.
